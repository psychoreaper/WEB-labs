export default function addName() {
    let elem = document.getElementById("app")
    elem.innerHTML = "Роцинский Иван Вячеславович M3306";
}

